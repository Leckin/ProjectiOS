#ifndef menuIcon_h
#define menuIcon_h


#define menuIcon @""

#endif